


<?php $__env->startSection('title', 'Menu'); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="text-center mt-3 pt-3 bg-white">
    <?php for($i = 0; $i < 3; $i++): ?>
      <div id="first-index-main" class="alert alert-info d-inline-block bg-dark text-white">
        Welcome to A&W Restaurant!
      </div>
    <?php endfor; ?>
  </div>
  <div id="second-index-main" class="container-fluid">
    <div class="container">
      <h3 id="second-index-main-first-title" class="h3">Burger</h3>  
      <div class="d-flex flex-sm-column flex-lg-row">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($d->id == 5): ?>
            <?php break; ?>
          <?php endif; ?>
          <div class="card" style="width: 18rem;">
            <img src=<?php echo e($d->image_path); ?> class="card-img-top" alt="Image Not Loaded">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($d->name); ?></h5>
              <p class="card-text"><?php echo e($d->price); ?></p>
              <p class="card-text"><?php echo e($d->desc); ?></p>
              <?php if($d->type == 'drink'): ?>
                <span class="badge bg-warning"><?php echo e($d->type); ?></span> 
              <?php else: ?>
                <span class="badge bg-danger"><?php echo e($d->type); ?></span>
              <?php endif; ?>
            </div>
          </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <h3 id="second-index-main-second-title" class="h3">Potato</h3> 
      <div class="d-flex flex-sm-column flex-lg-row">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php if($d->id == 5 || $d->id == 6 || $d->id == 7 || $d->id == 8): ?>
            <div class="card" style="width: 18rem;">
              <img src=<?php echo e($d->image_path); ?> class="card-img-top" alt="Image Not Loaded">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($d->name); ?></h5>
                <p class="card-text"><?php echo e($d->price); ?></p>
                <p class="card-text"><?php echo e($d->desc); ?></p>
                <?php if($d->type == 'drink'): ?>
                  <span class="badge bg-warning"><?php echo e($d->type); ?></span> 
                <?php else: ?>
                  <span class="badge bg-danger"><?php echo e($d->type); ?></span>
                <?php endif; ?>
              </div>
            </div> 
          <?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
      </div>
      <h3 id="second-index-main-third-title" class="h3">Drink</h3> 
      <div class="d-flex flex-sm-column flex-lg-row">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php if($d->id == 9 || $d->id == 10 || $d->id == 11 || $d->id == 12): ?>
            <div class="card" style="width: 18rem;">
              <img src=<?php echo e($d->image_path); ?> class="card-img-top" alt="Image Not Loaded">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($d->name); ?></h5>
                <p class="card-text"><?php echo e($d->price); ?></p>
                <p class="card-text"><?php echo e($d->desc); ?></p>
                <?php if($d->type == 'drink'): ?>
                  <span class="badge bg-warning"><?php echo e($d->type); ?></span> 
                <?php else: ?>
                  <span class="badge bg-danger"><?php echo e($d->type); ?></span>
                <?php endif; ?>
              </div>
            </div> 
          <?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
      </div>
      <h3 id="second-index-main-fourth-title" class="h3">Chicken</h3> 
      <div class="d-flex flex-sm-column flex-lg-row">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php if($d->id == 13 || $d->id == 14 || $d->id == 15 || $d->id == 16): ?>
            <div class="card" style="width: 18rem;">
              <img src=<?php echo e($d->image_path); ?> class="card-img-top" alt="Image Not Loaded">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($d->name); ?></h5>
                <p class="card-text"><?php echo e($d->price); ?></p>
                <p class="card-text"><?php echo e($d->desc); ?></p>
                <?php if($d->type == 'drink'): ?>
                  <span class="badge bg-warning"><?php echo e($d->type); ?></span> 
                <?php else: ?>
                  <span class="badge bg-danger"><?php echo e($d->type); ?></span>
                <?php endif; ?>
              </div>
            </div> 
          <?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php $i = 0; ?>
  <div class="text-center mt-3 pt-3 bg-white">
    <?php while($i < 3): ?>
      <div id="third-index-main" class="alert alert-info d-inline-block bg-dark text-white">
        Don't forget to order!
      </div>
      <?php $i++ ?>
    <?php endwhile; ?>
  </div>
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Win10\Downloads\Tugas 1 Web Prog\resources\views/index.blade.php ENDPATH**/ ?>