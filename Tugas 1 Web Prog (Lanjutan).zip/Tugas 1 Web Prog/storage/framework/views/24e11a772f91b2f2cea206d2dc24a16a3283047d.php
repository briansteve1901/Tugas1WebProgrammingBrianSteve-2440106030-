


<?php $__env->startSection('title', 'Party & Event'); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="party-and-event-main">
    <h1 id="party-and-event-main-title">Party & Event</h1>
    <h3 id="party-and-event-main-first-subtitle">Birthday</h3>
    <img id="party-and-event-main-first-image"src="<?php echo e(asset('images/partyandeventimages/birthday.jpg')); ?>" alt="Image Not Loaded">
    <h3 id="party-and-event-main-second-subtitle">Cooking</h3>
    <img id="party-and-event-main-second-image" src="<?php echo e(asset('images/partyandeventimages/cooking.jpg')); ?>" alt="Image Not Loaded">
    <h3 id="party-and-event-main-third-subtitle">Coorporate</h3>
    <img id="party-and-event-main-third-image" src="<?php echo e(asset('images/partyandeventimages/coorporate.jpg')); ?>" alt="Image Not Loaded">
    <h3 id="party-and-event-main-fourth-subtitle">Drawing</h3>
    <img id="party-and-event-main-fourth-image" src="<?php echo e(asset('images/partyandeventimages/drawing.jpg')); ?>" alt="Image Not Loaded">
  </div>
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Win10\Downloads\Tugas 1 Web Prog\resources\views/partyandevent.blade.php ENDPATH**/ ?>