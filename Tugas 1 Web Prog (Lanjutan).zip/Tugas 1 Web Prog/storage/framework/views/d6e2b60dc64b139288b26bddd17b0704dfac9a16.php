


<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="profile-main">
    <h1 id="profile-main-title">Our Root</h1>
    <img id="profile-main-first-image" src="<?php echo e(asset('images/profileimages/firstimageinprofile.jpg')); ?>" alt="Image Not Loaded">
    <p id="profile-main-first-paragraph">It started in 1919 in Lodi, California, when Roy W. Allen 
    sold his signature RB to world war fighters. Until now, RB in 
    every restaurant is prepared fresh every day, using real cane 
    sugar and the right combination of various quality ingredients. 
    Served using Frosty Mugs which makes RB the hallmark of A&W.</p>
    <img id="profile-main-second-image" src="<?php echo e(asset('images/profileimages/secondimageinprofile.jpg')); ?>" alt="Image Not Loaded">
    <p id="profile-main-second-paragraph">The name A&W itself is a combination of the initials of the 
    names of the founders of A&W, Roy W. Allen and Frank Wright. 
    Currently, A&W has spread all over the world by providing quality 
    ready-to-eat food supported by a positive work ethic, a quality 
    that we want to maintain in the future.</p>
    <img id="profile-main-third-image" src="<?php echo e(asset('images/profileimages/thirdimageinprofile.jpg')); ?>" alt="Image Not Loaded">
    <p id="profile-main-third-paragraph">Since A&W opened its first outlet in Indonesia in 1985, we have 
    continued to strive to provide the best service for every customer. 
    To date, A&W has served approximately 5 million customers every 
    month, in more than 230 A&W restaurants spread throughout Indonesia.</p>
  </div>
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Win10\Downloads\Tugas 1 Web Prog\resources\views/profile.blade.php ENDPATH**/ ?>