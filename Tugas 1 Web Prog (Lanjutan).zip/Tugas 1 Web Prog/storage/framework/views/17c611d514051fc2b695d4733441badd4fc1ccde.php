<nav id="header" class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark" id="navbarcolor">
  <div class="container-fluid">
    <a id="aw-logo-wrapper" class="navbar-brand" href="/home">
      <img src="<?php echo e(asset('images/headerimage/a&wlogo.png')); ?>" alt="Image Not Loaded">
    </a>
    <button id="burger-icon" class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ms-auto mt-2 text-center">
        <li class="nav-item" id="profile-menu">
          <a id="nav-item-link" class="nav-link active" aria-current="page" href="/profile">PROFILE</a>
        </li>
        <li class="nav-item" id="menu-menu">
          <a id="nav-item-link" class="nav-link active" aria-current="page" href="/menu">MENU</a>
        </li>
        <li class="nav-item" id="party-and-event-menu">
          <a id="nav-item-link" class="nav-link active" aria-current="page" href="/partyandevent">PARTY & EVENT</a>
        </li>
        <li class="nav-item" id="promo-menu">
          <a id="nav-item-link" class="nav-link active" aria-current="page" href="/promo">PROMO</a>
        </li>
      </ul>
    </div>
  </div>
</nav><?php /**PATH C:\Users\Win10\Downloads\Tugas 1 Web Prog\resources\views/header.blade.php ENDPATH**/ ?>