<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Product::query()->insert(
            [
                [
                    "id" => 1,
                    "name" => "Jumbo Chicken Sandwich",
                    "type" => "food",
                    "desc" => "You can't go wrong with this",
                    "price" => 25000,
                    "image_path" => "https://iili.io/p7vwml.png"
                ],
                [
                    "id" => 2,
                    "name" => "Cheese Burger",
                    "type" => "food",
                    "desc" => "Nothing too fancy, just tasty",
                    "price" => 30000,
                    "image_path" => "https://iili.io/p74b4I.png"
                ],
                [
                    "id" => 3,
                    "name" => "Deluxe Burger",
                    "type" => "food",
                    "desc" => "Beef makes everything better",
                    "price" => 36000,
                    "image_path" => "https://iili.io/p7PfDJ.png"
                ],
                [
                    "id" => 4,
                    "name" => "Veggie Burger",
                    "type" => "food",
                    "desc" => "Calling all veggie lovers",
                    "price" => 20000,
                    "image_path" => "https://iili.io/p7s2ja.png"
                ],
                [
                    "id" => 5,
                    "name" => "Perkedel",
                    "type" => "food",
                    "desc" => "All hail the potato",
                    "price" => 5000,
                    "image_path" => "https://iili.io/p7D2qb.png"
                ],
                [
                    "id" => 6,
                    "name" => "Duo Fries",
                    "type" => "food",
                    "desc" => "AWesome either way",
                    "price" => 20000,
                    "image_path" => "https://iili.io/p7m0fs.png"
                ],
                [
                    "id" => 7,
                    "name" => "Curly Fries",
                    "type" => "food",
                    "desc" => "The best around ever",
                    "price" => 20000,
                    "image_path" => "https://iili.io/p7pLjS.png"
                ],
                [
                    "id" => 8,
                    "name" => "French Fries",
                    "type" => "food",
                    "desc" => "A trusty sidekick",
                    "price" => 15000,
                    "image_path" => "https://iili.io/p7tpm7.png"
                ],
                [
                    "id" => 9,
                    "name" => "Rootbeer",
                    "type" => "drink",
                    "desc" => "Very Refreshing",
                    "price" => 30000,
                    "image_path" => "https://iili.io/yNE3n2.png"
                ],
                [
                    "id" => 10,
                    "name" => "Orange Juice",
                    "type" => "drink",
                    "desc" => "Citrus Awddiction",
                    "price" => 15000,
                    "image_path" => "https://iili.io/yNlw8b.png"
                ],
                [
                    "id" => 11,
                    "name" => "Ice Lemon Tea",
                    "type" => "drink",
                    "desc" => "Refreshing",
                    "price" => 10000,
                    "image_path" => "https://iili.io/yN085G.png"
                ],
                [
                    "id" => 12,
                    "name" => "Iced Green Tea Latte",
                    "type" => "drink",
                    "desc" => "Chilled smooth creamy matcha",
                    "price" => 20000,
                    "image_path" => "https://iili.io/yN0Zdu.png"
                ],
                [
                    "id" => 13,
                    "name" => "Golden Aroma Chicken",
                    "type" => "food",
                    "desc" => "Fresh is best",
                    "price" => 20000,
                    "image_path" => "https://iili.io/yN0yXV.png"
                ],
                [
                    "id" => 14,
                    "name" => "Spicy Aroma Chicken",
                    "type" => "food",
                    "desc" => "Every mouthful taste AWsome",
                    "price" => 17500,
                    "image_path" => "https://iili.io/yN1K7a.png"
                ],
                [
                    "id" => 15,
                    "name" => "Chicken Strips",
                    "type" => "food",
                    "desc" => "Hand-on juicy white meat",
                    "price" => 10000,
                    "image_path" => "https://iili.io/yN1aI4.png"
                ],
                [
                    "id" => 16,
                    "name" => "Chicken Chunks",
                    "type" => "food",
                    "desc" => "100% tender lovin",
                    "price" => 15000,
                    "image_path" => "https://iili.io/yN1G49.png"
                ]
            ]
        );
    }
}
