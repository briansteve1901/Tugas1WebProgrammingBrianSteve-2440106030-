@extends('template')

{{-- Untuk akses yield yang ingin diganti --}}
@section('title', 'Home')

@section('content')
  @include('header')
  <div class="home-main">
    <img id="home-main-image" src="{{asset('images/homeimage/a&wlogo.png')}}" alt="Image Not Loaded">
    <h1 id="home-main-title">Welcome to A&W Restaurant Indonesia!</h1>
  </div>
  @include('footer')
@endsection