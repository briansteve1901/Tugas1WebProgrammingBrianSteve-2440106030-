@extends('template')

{{-- Untuk akses yield yang ingin diganti --}}
@section('title', 'Party & Event')

@section('content')
  @include('header')
  <div class="party-and-event-main">
    <h1 id="party-and-event-main-title">Party & Event</h1>
    <h3 id="party-and-event-main-first-subtitle">Birthday</h3>
    <img id="party-and-event-main-first-image"src="{{asset('images/partyandeventimages/birthday.jpg')}}" alt="Image Not Loaded">
    <h3 id="party-and-event-main-second-subtitle">Cooking</h3>
    <img id="party-and-event-main-second-image" src="{{asset('images/partyandeventimages/cooking.jpg')}}" alt="Image Not Loaded">
    <h3 id="party-and-event-main-third-subtitle">Coorporate</h3>
    <img id="party-and-event-main-third-image" src="{{asset('images/partyandeventimages/coorporate.jpg')}}" alt="Image Not Loaded">
    <h3 id="party-and-event-main-fourth-subtitle">Drawing</h3>
    <img id="party-and-event-main-fourth-image" src="{{asset('images/partyandeventimages/drawing.jpg')}}" alt="Image Not Loaded">
  </div>
  @include('footer')
@endsection