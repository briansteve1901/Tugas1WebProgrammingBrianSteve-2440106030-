@extends('template')

{{-- Untuk akses yield yang ingin diganti --}}
@section('title', 'Promo')

@section('content')
  @include('header')
  <div class="promo-main">
    <h1 id="promo-main-title">Promo</h1>
    <img id="promo-main-first-image" src="{{asset('images/promoimages/firstpromo.jpg')}}" alt="Image Not Loaded">
    <img id="promo-main-second-image" src="{{asset('images/promoimages/secondpromo.jpg')}}" alt="Image Not Loaded">
    <img id="promo-main-third-image" src="{{asset('images/promoimages/thirdpromo.jpg')}}" alt="Image Not Loaded">
  </div>
  @include('footer')
@endsection