@extends('template')

{{-- Untuk akses yield yang ingin diganti --}}
@section('title', 'Menu')

@section('content')
  @include('header')
  <div class="text-center mt-3 pt-3 bg-white">
    @for($i = 0; $i < 3; $i++)
      <div id="first-index-main" class="alert alert-info d-inline-block bg-dark text-white">
        Welcome to A&W Restaurant!
      </div>
    @endfor
  </div>
  <div id="second-index-main" class="container-fluid">
    <div class="container">
      <h3 id="second-index-main-first-title" class="h3">Burger</h3>  
      <div class="d-flex flex-sm-column flex-lg-row">
        @foreach($data as $d)
          @if($d->id == 5)
            @break
          @endif
          <div class="card" style="width: 18rem;">
            <img src={{$d->image_path}} class="card-img-top" alt="Image Not Loaded">
            <div class="card-body">
              <h5 class="card-title">{{$d->name}}</h5>
              <p class="card-text">{{$d->price}}</p>
              <p class="card-text">{{$d->desc}}</p>
              @if($d->type == 'drink')
                <span class="badge bg-warning">{{$d->type}}</span> 
              @else
                <span class="badge bg-danger">{{$d->type}}</span>
              @endif
            </div>
          </div>  
        @endforeach
      </div>
      <h3 id="second-index-main-second-title" class="h3">Potato</h3> 
      <div class="d-flex flex-sm-column flex-lg-row">
        @forelse($data as $d)
          @if($d->id == 5 || $d->id == 6 || $d->id == 7 || $d->id == 8)
            <div class="card" style="width: 18rem;">
              <img src={{$d->image_path}} class="card-img-top" alt="Image Not Loaded">
              <div class="card-body">
                <h5 class="card-title">{{$d->name}}</h5>
                <p class="card-text">{{$d->price}}</p>
                <p class="card-text">{{$d->desc}}</p>
                @if($d->type == 'drink')
                  <span class="badge bg-warning">{{$d->type}}</span> 
                @else
                  <span class="badge bg-danger">{{$d->type}}</span>
                @endif
              </div>
            </div> 
          @endif 
        @empty
        @endforelse
      </div>
      <h3 id="second-index-main-third-title" class="h3">Drink</h3> 
      <div class="d-flex flex-sm-column flex-lg-row">
        @forelse($data as $d)
          @if($d->id == 9 || $d->id == 10 || $d->id == 11 || $d->id == 12)
            <div class="card" style="width: 18rem;">
              <img src={{$d->image_path}} class="card-img-top" alt="Image Not Loaded">
              <div class="card-body">
                <h5 class="card-title">{{$d->name}}</h5>
                <p class="card-text">{{$d->price}}</p>
                <p class="card-text">{{$d->desc}}</p>
                @if($d->type == 'drink')
                  <span class="badge bg-warning">{{$d->type}}</span> 
                @else
                  <span class="badge bg-danger">{{$d->type}}</span>
                @endif
              </div>
            </div> 
          @endif 
        @empty
        @endforelse
      </div>
      <h3 id="second-index-main-fourth-title" class="h3">Chicken</h3> 
      <div class="d-flex flex-sm-column flex-lg-row">
        @forelse($data as $d)
          @if($d->id == 13 || $d->id == 14 || $d->id == 15 || $d->id == 16)
            <div class="card" style="width: 18rem;">
              <img src={{$d->image_path}} class="card-img-top" alt="Image Not Loaded">
              <div class="card-body">
                <h5 class="card-title">{{$d->name}}</h5>
                <p class="card-text">{{$d->price}}</p>
                <p class="card-text">{{$d->desc}}</p>
                @if($d->type == 'drink')
                  <span class="badge bg-warning">{{$d->type}}</span> 
                @else
                  <span class="badge bg-danger">{{$d->type}}</span>
                @endif
              </div>
            </div> 
          @endif 
        @empty
        @endforelse
      </div>
    </div>
  </div>
  <?php $i = 0; ?>
  <div class="text-center mt-3 pt-3 bg-white">
    @while($i < 3)
      <div id="third-index-main" class="alert alert-info d-inline-block bg-dark text-white">
        Don't forget to order!
      </div>
      <?php $i++ ?>
    @endwhile
  </div>
  @include('footer')
@endsection