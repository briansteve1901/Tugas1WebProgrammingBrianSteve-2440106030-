<div class="footer">
    <div class="footer-social-media">
        <div class="footer-social-media-instagram"><img src="{{asset('images/footerimages/instagramlogo.png')}}" alt="Image Not Loaded"></div>
        <div class="footer-social-media-facebook"><img src="{{asset('images/footerimages/facebooklogo.png')}}" alt="Image Not Loaded"></div>
        <div class="footer-social-media-twitter"><img src="{{asset('images/footerimages/twitterlogo.png')}}" alt="Image Not Loaded"></div>
    </div>
    <span id="footer-copyright-text">COPYRIGHT 2022 A&W</span>
</div>