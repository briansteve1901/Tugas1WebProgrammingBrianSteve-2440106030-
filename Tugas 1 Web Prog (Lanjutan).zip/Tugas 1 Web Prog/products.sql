-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2022 at 04:24 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tugas1webprog`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `type`, `desc`, `image_path`, `created_at`, `updated_at`) VALUES
(1, 'Jumbo Chicken Sandwich', 25000, 'food', 'You can\'t go wrong with this', 'https://iili.io/p7vwml.png', NULL, NULL),
(2, 'Cheese Burger', 30000, 'food', 'Nothing too fancy, just tasty', 'https://iili.io/p74b4I.png', NULL, NULL),
(3, 'Deluxe Burger', 36000, 'food', 'Beef makes everything better', 'https://iili.io/p7PfDJ.png', NULL, NULL),
(4, 'Veggie Burger', 20000, 'food', 'Calling all veggie lovers', 'https://iili.io/p7s2ja.png', NULL, NULL),
(5, 'Perkedel', 5000, 'food', 'All hail the potato', 'https://iili.io/p7D2qb.png', NULL, NULL),
(6, 'Duo Fries', 20000, 'food', 'AWesome either way', 'https://iili.io/p7m0fs.png', NULL, NULL),
(7, 'Curly Fries', 20000, 'food', 'The best around ever', 'https://iili.io/p7pLjS.png', NULL, NULL),
(8, 'French Fries', 15000, 'food', 'A trusty sidekick', 'https://iili.io/p7tpm7.png', NULL, NULL),
(9, 'Root Beer', 30000, 'drink', 'Very refreshing', 'https://awrestaurants.com/sites/default/files/rootbeer_slider.jpg', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
