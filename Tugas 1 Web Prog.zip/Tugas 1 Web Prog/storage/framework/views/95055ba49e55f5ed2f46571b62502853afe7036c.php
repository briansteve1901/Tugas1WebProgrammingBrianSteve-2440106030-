<div class="footer">
    <div class="footer-social-media">
        <div class="footer-social-media-instagram"><img src="<?php echo e(asset('instagramlogo.png')); ?>" alt="Image Not Loaded"></div>
        <div class="footer-social-media-facebook"><img src="<?php echo e(asset('facebooklogo.png')); ?>" alt="Image Not Loaded"></div>
        <div class="footer-social-media-twitter"><img src="<?php echo e(asset('twitterlogo.png')); ?>" alt="Image Not Loaded"></div>
    </div>
    <span id="footer-copyright-text">COPYRIGHT 2022 A&W</span>
</div><?php /**PATH C:\Users\Win10\Downloads\session 2\resources\views/footer.blade.php ENDPATH**/ ?>