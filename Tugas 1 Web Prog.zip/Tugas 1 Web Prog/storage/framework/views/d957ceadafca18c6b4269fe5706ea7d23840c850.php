


<?php $__env->startSection('tittle', 'Session 2 | Homepage'); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <br><br><br><br><br>
  <div class="text-center mt-3 pt-3 bg-white">
    <?php for($i = 0; $i < 3; $i++): ?>
      <div class="alert alert-info d-inline-block bg-dark text-white">
        Welcome to A&W Restaurant!
      </div>
    <?php endfor; ?>
  </div>
  <br>
  <div class="container-fluid">
    <div class="container">
      <h3 class="h3">Burger</h3>  
      <div class="d-flex">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($d->id == 5): ?>
            <?php break; ?>
          <?php endif; ?>
          <div class="card" style="width: 18rem;">
            <img src=<?php echo e($d->image_path); ?> class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($d->name); ?></h5>
              <p class="card-text"><?php echo e($d->price); ?></p>
              <p class="card-text"><?php echo e($d->desc); ?></p>
              <?php if($d->type == 'drink'): ?>
                <span class="badge bg-warning"><?php echo e($d->type); ?></span> 
              <?php else: ?>
                <span class="badge bg-danger"><?php echo e($d->type); ?></span>
              <?php endif; ?>
            </div>
          </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <br>
      <br>
      <h3 class="h3">Potato</h3> 
      <div class="d-flex">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php if($d->id == 5 || $d->id == 6 || $d->id == 7 || $d->id == 8): ?>
            <div class="card" style="width: 18rem;">
              <img src=<?php echo e($d->image_path); ?> class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($d->name); ?></h5>
                <p class="card-text"><?php echo e($d->price); ?></p>
                <p class="card-text"><?php echo e($d->desc); ?></p>
                <?php if($d->type == 'drink'): ?>
                  <span class="badge bg-warning"><?php echo e($d->type); ?></span> 
                <?php else: ?>
                  <span class="badge bg-danger"><?php echo e($d->type); ?></span>
                <?php endif; ?>
              </div>
            </div> 
          <?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
      </div>
      <br>
      <br>
      <h3 class="h3">Root Beer</h3> 
      <div class="d-flex">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php if($d->id == 9): ?>
            <div class="card" style="width: 18rem;">
              <img src=<?php echo e($d->image_path); ?> class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($d->name); ?></h5>
                <p class="card-text"><?php echo e($d->price); ?></p>
                <p class="card-text"><?php echo e($d->desc); ?></p>
                <?php if($d->type == 'drink'): ?>
                  <span class="badge bg-warning"><?php echo e($d->type); ?></span> 
                <?php else: ?>
                  <span class="badge bg-danger"><?php echo e($d->type); ?></span>
                <?php endif; ?>
              </div>
            </div> 
          <?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
      </div>
      <br> 
      <?php $i = 0; ?>
      <div class="text-center mt-3 pt-3 bg-white">
        <?php while($i < 3): ?>
          <div class="alert alert-info d-inline-block bg-dark text-white">
            Don't forget to order!
          </div>
          <?php $i++ ?>
        <?php endwhile; ?>
      </div>
    </div>
  </div>
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Win10\Downloads\Tugas 1 Web Prog\resources\views/index.blade.php ENDPATH**/ ?>