<nav id="header" class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a id="aw-logo-wrapper" class="navbar-brand" href="#">
          <img src="<?php echo e(asset('a&wlogo.png')); ?>" alt="Image Not Loaded">
        </a>
    </div>
</nav><?php /**PATH C:\Users\Win10\Downloads\Tugas 1 Web Prog\resources\views/header.blade.php ENDPATH**/ ?>