<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Product::query()->insert(
            [
                [
                    "id" => 1,
                    "name" => "Jumbo Chicken Sandwich",
                    "type" => "food",
                    "desc" => "You can't go wrong with this",
                    "price" => 25000,
                    "image_path" => "https://iili.io/p7vwml.png"
                ],
                [
                    "id" => 2,
                    "name" => "Cheese Burger",
                    "type" => "food",
                    "desc" => "Nothing too fancy, just tasty",
                    "price" => 30000,
                    "image_path" => "https://iili.io/p74b4I.png"
                ],
                [
                    "id" => 3,
                    "name" => "Deluxe Burger",
                    "type" => "food",
                    "desc" => "Beef makes everything better",
                    "price" => 36000,
                    "image_path" => "https://iili.io/p7PfDJ.png"
                ],
                [
                    "id" => 4,
                    "name" => "Veggie Burger",
                    "type" => "food",
                    "desc" => "Calling all veggie lovers",
                    "price" => 20000,
                    "image_path" => "https://iili.io/p7s2ja.png"
                ],
                [
                    "id" => 5,
                    "name" => "Perkedel",
                    "type" => "food",
                    "desc" => "All hail the potato",
                    "price" => 5000,
                    "image_path" => "https://iili.io/p7D2qb.png"
                ],
                [
                    "id" => 6,
                    "name" => "Duo Fries",
                    "type" => "food",
                    "desc" => "AWesome either way",
                    "price" => 20000,
                    "image_path" => "https://iili.io/p7m0fs.png"
                ],
                [
                    "id" => 7,
                    "name" => "Curly Fries",
                    "type" => "food",
                    "desc" => "The best around ever",
                    "price" => 20000,
                    "image_path" => "https://iili.io/p7pLjS.png"
                ],
                [
                    "id" => 8,
                    "name" => "French Fries",
                    "type" => "food",
                    "desc" => "A trusty sidekick",
                    "price" => 15000,
                    "image_path" => "https://iili.io/p7tpm7.png"
                ],
                [
                    "id" => 9,
                    "name" => "Rootbeer",
                    "type" => "drink",
                    "desc" => "Very Refreshing",
                    "price" => 30000,
                    "image_path" => "https://awrestaurants.com/sites/default/files/rootbeer_slider.jpg"
                ]
            ]
        );
    }
}
