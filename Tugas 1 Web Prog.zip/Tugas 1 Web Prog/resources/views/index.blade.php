@extends('template')

{{-- Untuk akses yield yang ingin diganti --}}
@section('tittle', 'Session 2 | Homepage')

@section('content')
  @include('header')
  <br><br><br><br><br>
  <div class="text-center mt-3 pt-3 bg-white">
    @for($i = 0; $i < 3; $i++)
      <div class="alert alert-info d-inline-block bg-dark text-white">
        Welcome to A&W Restaurant!
      </div>
    @endfor
  </div>
  <br>
  <div class="container-fluid">
    <div class="container">
      <h3 class="h3">Burger</h3>  
      <div class="d-flex">
        @foreach($data as $d)
          @if($d->id == 5)
            @break
          @endif
          <div class="card" style="width: 18rem;">
            <img src={{$d->image_path}} class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">{{$d->name}}</h5>
              <p class="card-text">{{$d->price}}</p>
              <p class="card-text">{{$d->desc}}</p>
              @if($d->type == 'drink')
                <span class="badge bg-warning">{{$d->type}}</span> 
              @else
                <span class="badge bg-danger">{{$d->type}}</span>
              @endif
            </div>
          </div>  
        @endforeach
      </div>
      <br>
      <br>
      <h3 class="h3">Potato</h3> 
      <div class="d-flex">
        @forelse($data as $d)
          @if($d->id == 5 || $d->id == 6 || $d->id == 7 || $d->id == 8)
            <div class="card" style="width: 18rem;">
              <img src={{$d->image_path}} class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">{{$d->name}}</h5>
                <p class="card-text">{{$d->price}}</p>
                <p class="card-text">{{$d->desc}}</p>
                @if($d->type == 'drink')
                  <span class="badge bg-warning">{{$d->type}}</span> 
                @else
                  <span class="badge bg-danger">{{$d->type}}</span>
                @endif
              </div>
            </div> 
          @endif 
        @empty
        @endforelse
      </div>
      <br>
      <br>
      <h3 class="h3">Root Beer</h3> 
      <div class="d-flex">
        @forelse($data as $d)
          @if($d->id == 9)
            <div class="card" style="width: 18rem;">
              <img src={{$d->image_path}} class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">{{$d->name}}</h5>
                <p class="card-text">{{$d->price}}</p>
                <p class="card-text">{{$d->desc}}</p>
                @if($d->type == 'drink')
                  <span class="badge bg-warning">{{$d->type}}</span> 
                @else
                  <span class="badge bg-danger">{{$d->type}}</span>
                @endif
              </div>
            </div> 
          @endif 
        @empty
        @endforelse
      </div>
      <br> 
      <?php $i = 0; ?>
      <div class="text-center mt-3 pt-3 bg-white">
        @while($i < 3)
          <div class="alert alert-info d-inline-block bg-dark text-white">
            Don't forget to order!
          </div>
          <?php $i++ ?>
        @endwhile
      </div>
    </div>
  </div>
  @include('footer')
@endsection